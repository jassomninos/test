<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title>Pemup - <?php echo e(Route::currentRouteName()); ?></title>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('admin_assets/assets/img/favicon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin_assets/assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin_assets/assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin_assets/assets/plugins/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin_assets/assets/plugins/simple-calendar/simple-calendar.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin_assets/assets/assets/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin_assets/assets/css/feather.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin_assets/assets/css/style.css')); ?>"><?php /**PATH C:\xampp\htdocs\laravelProject\whatsappClon\resources\views/admin/includes/head.blade.php ENDPATH**/ ?>