<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div class="main-wrapper">
        <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-wrapper">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <script src="<?php echo e(asset('admin_assets/assets/js/jquery-3.6.0.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin_assets/assets/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin_assets/assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin_assets/assets/plugins/apexchart/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/assets/plugins/apexchart/dsh-apaxcharts.js')); ?>"></script>

    <script src="<?php echo e(asset('admin_assets/assets/plugins/simple-calendar/jquery.simple-calendar.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/assets/js/calander.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/assets/plugins/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/assets/js/script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravelProject\whatsappClon\resources\views/admin/layouts/default.blade.php ENDPATH**/ ?>